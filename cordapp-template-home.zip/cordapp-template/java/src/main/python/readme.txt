Edit jython.sh as appropriate, start up a node and then run

./jython.sh ExampleClientRPC.py

or

./jython.sh

and copy in the imports followed by everything after __main__ (without the indentation)